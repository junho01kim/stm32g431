/*
 * icm20498.h
 *
 *  Created on: Jul 26, 2023
 *      Author: junho
 */

#ifndef INC_ICM20498_H_
#define INC_ICM20498_H_


typedef struct __acc_t
{
	int16_t xacc;
	int16_t yacc;
	int16_t zacc;

} acc_t;
typedef struct __zyro_t
{
	int16_t xzyro;
	int16_t yzyro;
	int16_t zzyro;

} zyro_t;
typedef struct __temp_t
{
	int16_t temp;

} temp_t;
typedef struct __sensordata_t
{
	acc_t acc;
	zyro_t zyro;
	temp_t temp;

} sensordata_t;

typedef struct __Icm20498_HandleTypeDef
{
	I2C_HandleTypeDef *phi2c1;
	sensordata_t sensordata;
	uint8_t i2ctxdata[10];
	uint8_t i2crxdata[20];
	uint32_t cnt;

} Icm20498_HandleTypeDef;
uint8_t testdataread(I2C_HandleTypeDef *phi2c1);
void initsensor(I2C_HandleTypeDef *phi2c1);


void swihandler(void);

void genswi(void);

void initswi(void);


void ledhandler(void);
#endif /* INC_ICM20498_H_ */
