/*
 * icm20498.c
 *
 *  Created on: Jul 26, 2023
 *      Author: junho
 */
//#include "main.h"
#include "stm32g4xx_hal.h"
#include "icm20498.h"

#define DevAdressICM (0x68<<1)
//extern I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef *pi2c = NULL;
Icm20498_HandleTypeDef icm20498handle;

uint8_t testdataread(I2C_HandleTypeDef *phi2c1)
{
	uint8_t i2ctxdata[4]={0};
	uint8_t i2crxdata[4]={0};
	i2ctxdata[0]=0;
	HAL_I2C_Master_Transmit(phi2c1, DevAdressICM, i2ctxdata, 1, 10);
	HAL_I2C_Master_Receive(phi2c1, DevAdressICM, i2crxdata, 1, 10);
	return i2crxdata[0];
}
/*
void DevRst(void)
{
	uint8_t i2ctxdata[4]={0};
	uint8_t i2crxdata[4]={0};

	i2ctxdata[0]=0;
	HAL_I2C_Master_Transmit(phi2c1, DevAdressICM, i2ctxdata, 1, 10);
	HAL_I2C_Master_Receive(phi2c1, DevAdressICM, i2crxdata, 1, 10);

	i2ctxdata[0]=0;
	HAL_I2C_Master_Transmit(pi2c, DevAdressICM, i2ctxdata, 2, 10);
}

void LowPwr(uint8_t lp)
{
	if(lp != 0)
	{

	}else{

	}

}

void DevSleep(uint8_t sleep)
{
	if(sleep != 0)
	{

	}else{

	}
}
*/
void initsensor(I2C_HandleTypeDef *phi2c1)
{
	//pi2c = phi2c1;
	uint32_t temp = 0;
	icm20498handle.phi2c1 = phi2c1;

	icm20498handle.i2ctxdata[0]=6;//6 address
	icm20498handle.i2ctxdata[1]=1<<7;//sleep off
	HAL_I2C_Master_Transmit(icm20498handle.phi2c1, DevAdressICM, icm20498handle.i2ctxdata, 2, 10);
	HAL_Delay(10);

	initswi();

	icm20498handle.i2ctxdata[0]=6;//6 address
	icm20498handle.i2ctxdata[1]=1;//sleep off
	HAL_I2C_Master_Transmit(icm20498handle.phi2c1, DevAdressICM, icm20498handle.i2ctxdata, 2, 10);

	icm20498handle.i2ctxdata[0]=17;//int reg
	icm20498handle.i2ctxdata[1]=1;//int on
	HAL_I2C_Master_Transmit(icm20498handle.phi2c1, DevAdressICM, icm20498handle.i2ctxdata, 2, 10);

}
void initsensorfifo(I2C_HandleTypeDef *phi2c1)
{
	pi2c = phi2c1;
	uint8_t i2ctxdata[4]={0};
	uint8_t i2crxdata[4]={0};

	i2ctxdata[0]=6;//6 address
	i2ctxdata[1]=1;//sleep off
	HAL_I2C_Master_Transmit(pi2c, DevAdressICM, i2ctxdata, 2, 10);

}

void sensorread(void)
{
	//pi2c = phi2c1;
	  //i2ctxdata[0]=45;
	  //HAL_I2C_Master_Transmit(phi2c1, DevAdressICM, i2ctxdata, 1, 10);
	  //HAL_I2C_Master_Receive(phi2c1, DevAdressICM, i2crxdata, 14, 10);
	  HAL_I2C_Mem_Read(icm20498handle.phi2c1, DevAdressICM, 45,1, icm20498handle.i2crxdata, 14, 10);
}
void sensorreaddma(void)
{
	//pi2c = phi2c1;
	//uint8_t i2ctxdata[4]={0};
	//uint8_t i2crxdata[4]={0};
	  //i2ctxdata[0]=45;
	  //HAL_I2C_Master_Transmit(pi2c, DevAdressICM, i2ctxdata, 1, 10);
	  //slaveaddress = 0x68|(0x1<<7);// 1 read 0 write
	  //HAL_I2C_Master_Receive_DMA(pi2c,DevAdressICM ,data,14);
	  HAL_I2C_Mem_Read_DMA(icm20498handle.phi2c1, DevAdressICM, 45,1,  icm20498handle.i2crxdata, 14);

	  //HAL_I2C_Master_Receive(&hi2c1, (0x68<<1), i2crxdata, 14, 10);
}

void sensorreadfifo(I2C_HandleTypeDef *phi2c1,uint8_t *data)
{
	pi2c = phi2c1;
	uint8_t i2ctxdata[4]={0};
	uint8_t i2crxdata[4]={0};
	  i2ctxdata[0]=45;
	  HAL_I2C_Master_Transmit(pi2c, DevAdressICM, i2ctxdata, 1, 10);
	  //slaveaddress = 0x68|(0x1<<7);// 1 read 0 write
	  //HAL_I2C_Master_Receive_DMA(&hi2c1,(0x68<<1) ,&testi2c,1);
	  HAL_I2C_Master_Receive(pi2c, DevAdressICM, data, 14, 10);
}



void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  /* Prevent unused argument(s) compilation warning */
  //UNUSED(GPIO_Pin);
  if(GPIO_Pin == GPIO_PIN_13)
  {
	 // HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
  }else if(GPIO_Pin == GPIO_PIN_9)
  {
	  sensorreaddma();
  }
  /* NOTE: This function should not be modified, when the callback is needed,
           the HAL_GPIO_EXTI_Callback could be implemented in the user file
   */
}
void HAL_I2C_MemRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
  /* Prevent unused argument(s) compilation warning */

  uint32_t temp = 0;
  UNUSED(hi2c);
 // HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
  icm20498handle.sensordata.acc.xacc = (icm20498handle.i2crxdata[0])<<8;
  icm20498handle.sensordata.acc.xacc |= (icm20498handle.i2crxdata[1])<<0;
  icm20498handle.sensordata.acc.yacc = (icm20498handle.i2crxdata[2])<<8;
  icm20498handle.sensordata.acc.yacc |= (icm20498handle.i2crxdata[3])<<0;
  icm20498handle.sensordata.acc.zacc = (icm20498handle.i2crxdata[4])<<8;
  icm20498handle.sensordata.acc.zacc |= icm20498handle.i2crxdata[5]<<0;

  icm20498handle.sensordata.zyro.xzyro = icm20498handle.i2crxdata[6]<<8;
  icm20498handle.sensordata.zyro.xzyro |= icm20498handle.i2crxdata[7]<<0;
  icm20498handle.sensordata.zyro.yzyro = icm20498handle.i2crxdata[8]<<8;
  icm20498handle.sensordata.zyro.yzyro |= icm20498handle.i2crxdata[9]<<0;
  icm20498handle.sensordata.zyro.zzyro = icm20498handle.i2crxdata[10]<<8;
  icm20498handle.sensordata.zyro.zzyro |= icm20498handle.i2crxdata[11]<<0;

  icm20498handle.sensordata.temp.temp = icm20498handle.i2crxdata[12]<<8;
  icm20498handle.sensordata.temp.temp |= icm20498handle.i2crxdata[13]<<0;
  icm20498handle.sensordata.temp.temp = (int16_t)((((int32_t)(icm20498handle.sensordata.temp.temp))*10000)/33387+(int32_t)2100);
  icm20498handle.cnt++;
  if(icm20498handle.cnt >= 100)
  {
	  icm20498handle.cnt = 0;
	 // __ASM volatile ("SWI 1");
	  //EXTI_SWIER1
	  genswi();


  }
  /* NOTE : This function should not be modified, when the callback is needed,
            the HAL_I2C_MemRxCpltCallback could be implemented in the user file
   */
}

/*
__STATIC_FORCEINLINE uint32_t __SADD8(uint32_t op1, uint32_t op2)
{
  uint32_t result;

  __ASM volatile ("sadd8 %0, %1, %2" : "=r" (result) : "r" (op1), "r" (op2) );
  return(result);
}
*/
void swihandler(void)
{
	uint32_t temp = 0;
	  temp = EXTI->PR1;
	  if((0x1&temp) == 0x1)
	  {
		  temp |= 1;
		  EXTI->PR1 = temp;
		  HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
	  }
}
EXTI_HandleTypeDef uhexti = {0};
EXTI_ConfigTypeDef ExtiConfig ={0};
void genswi(void)
{
#if 0
	uint32_t temp = 0;
	  temp = EXTI->SWIER1;
	  temp |= 1;
	  EXTI->SWIER1 = temp;
#endif

	  //uhexti.Line = EXTI_CONFIG|0x1;
	  //uhexti.PendingCallback = ledhandler;
	  HAL_EXTI_GenerateSWI(&uhexti);
}

void initswi(void)
{
#if 0
	uint32_t temp = 0;
	  temp = EXTI->IMR1;
	  temp |= 1;
	  EXTI->IMR1 = temp;
#endif


		//uhexti.Line = EXTI_CONFIG|0x1;
		//uhexti.PendingCallback = ledhandler;
		ExtiConfig.Line = EXTI_LINE_0;
		ExtiConfig.Mode = EXTI_MODE_INTERRUPT; //(EXTI_MODE_EVENT | EXTI_MODE_INTERRUPT);
		ExtiConfig.Trigger = EXTI_TRIGGER_RISING;// EXTI_TRIGGER_NONE;
		ExtiConfig.GPIOSel = EXTI_GPIOA;

		HAL_EXTI_SetConfigLine(&uhexti, &ExtiConfig);
		HAL_EXTI_RegisterCallback(&uhexti, HAL_EXTI_COMMON_CB_ID, &ledhandler);
		HAL_NVIC_SetPriority(EXTI0_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(EXTI0_IRQn);

	  /*
	  temp = EXTI->EMR1;
	  temp |= 1;
	  EXTI->EMR1 = temp;
	  */
}

void ledhandler(void)
{
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
	HAL_EXTI_ClearPending(&uhexti, EXTI_TRIGGER_RISING);


}
